use audit;

-- includes commonly used queries used for management monitoring and MI, see separate scripts for stored functions/procedures/views

/* 
Return sponsor, stakeholder and manager for each audit in the 2022 and 2023 audit plans; 
Join audit table to team, manager, stakeholder, sponsor &  status tables (all left joins)
concatenate two columns to return a single string
Limit to audits in the 2022 and 2023 plans only - use subquery
*/ 

SELECT 
	a.audit_name,
	CONCAT(s.sponsor_firstname, ' ', s.sponsor_lastname) as audit_sponsor,
	CONCAT(st.stakeholder_firstname, ' ', st.stakeholder_lastname) AS stakeholder,
    CONCAT(m.manager_firstname, ' ', m.manager_lastname) AS manager
FROM 
	audit a
LEFT JOIN team t 
	ON t.team_id = a.team_id
LEFT JOIN manager m
	ON t.team_id = m.team_id
LEFT JOIN stakeholder st 
	ON a.stakeholder_id = st.stakeholder_id
LEFT JOIN sponsor s 
	ON a.sponsor_id = s.sponsor_id
LEFT JOIN audit_status sta
	ON a.status_id = sta.status_id
WHERE sta.current_status <>'cancelled'
AND a.plan_id IN 
-- subquery to limit result to audits in the 2022 and 2023 plan years only 
	(SELECT 
		DISTINCT(a.plan_id)
        FROM audit a 
        LEFT JOIN plan p 
			ON a.plan_id = p.plan_id
		WHERE p.audit_plan IN (2022, 2023)
	)	
ORDER BY audit_name;



/* finding the audit that took the longest time to complete using CTE and subquery*/ 

-- create a CTE to work out audit duration
WITH duration AS (
SELECT 
audit_name,
notification_date,
final_report_date,
DATEDIFF(final_report_date, notification_date) AS audit_duration
FROM audit
WHERE final_report_date IS NOT NULL)

SELECT
audit_name,
audit_duration
FROM
duration
WHERE
audit_duration = (SELECT MAX(audit_duration) FROM duration); -- subquery to work out the longest audit duration




/* Time intelligence and aggregate functions - working out the shortest,longest and
average duration of completed audits by plan year using a CTE */ 

-- CTE to work out audit duration and bring in plan year from Plan table
WITH duration_breakdown AS (
SELECT 
audit_name,
audit_plan AS plan_year,
notification_date,
final_report_date,
DATEDIFF(final_report_date, notification_date) AS audit_duration
FROM audit
LEFT JOIN plan ON audit.plan_id = plan.plan_id
WHERE final_report_date IS NOT NULL)

-- query to work out longest, shortest and average audit durations by plan year
SELECT 
plan_year,
MAX(audit_duration) AS longest_audit,
MIN(audit_duration) AS shortest_audit,
ROUND(AVG(audit_duration),0) as average_duration
FROM duration_breakdown
GROUP BY plan_year; -- we haven't completed any 2023 audits yet so 2023 won't be included in the output





  
  /* 
  grades broken down by audit manager - to see if anyone has 'form' for being harsh or lenient! 
  uses aggregation, case and group by to pivot results
  */ 
  
  SELECT 
		CONCAT(m.manager_firstname, ' ', m.manager_lastname) AS manager,
        COUNT(a.grade_id) AS completed_audits,
        COUNT(CASE WHEN a.grade_id = 1 THEN a.grade_id ELSE NULL END) AS 'effective',
		COUNT(CASE WHEN a.grade_id = 2 THEN a.grade_id ELSE NULL END) AS 'needs_improvement_+',
        COUNT(CASE WHEN a.grade_id = 3 THEN a.grade_id ELSE NULL END) AS 'needs_improvement',
        COUNT(CASE WHEN a.grade_id = 4 THEN a.grade_id ELSE NULL END) AS 'needs_improvement_-',
        COUNT(CASE WHEN a.grade_id = 5 THEN a.grade_id ELSE NULL END) AS 'ineffective-'
FROM manager m
LEFT JOIN team t ON t.team_id = m.team_id
LEFT JOIN audit a ON t.team_id = a.team_id
LEFT JOIN grade g ON g.grade_id = a.grade_id
GROUP BY manager
;

/* displays all feedback received broken down per audit, with an average across all five questions cores 
(note comments field is optional)*/

SELECT
    a.audit_name,
    CONCAT(st.stakeholder_firstname, ' ', st.stakeholder_lastname) AS stakeholder,
    f.q1_score,
    f.q2_score,
    f.q3_score,
    f.q4_score,
    f.q5_score,
    ROUND(((f.q1_score + f.q2_score + f.q3_score + f.q4_score + f.q5_score)/5),0) AS avg_score,
    f.comments
    
    FROM audit a
    INNER JOIN stakeholder st ON a.stakeholder_id = st.stakeholder_id
    INNER JOIN feedback f ON a.audit_id = f.audit_id;
    
