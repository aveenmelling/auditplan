/* TRIGGER - prevents user from updating a record in the Audit table with a final report
date that is earlier than the draft report date */ 

DELIMITER $$
CREATE TRIGGER final_report_check
    BEFORE UPDATE
    ON audit FOR EACH ROW
BEGIN 
IF NEW.final_report_date < NEW.draft_report_date THEN 
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'final report cannot be earlier than draft report'; -- error message
END IF;
END$$    
DELIMITER ;

-- update a record to show trigger working
UPDATE audit 
SET final_report_date = '2023-02-27'
WHERE audit_id = 34;