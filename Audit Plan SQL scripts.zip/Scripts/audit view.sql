/* Create a view to show all audits that are currently in-flight, i.e. a notification has been sent 
to formally kick off the audit but the final report has not yet been issued */

CREATE VIEW audits_in_flight AS
SELECT 
a.audit_id,
a.audit_name,
t.team_name,
CONCAT(s.sponsor_firstname, ' ', s.sponsor_lastname) as audit_sponsor,
a.notification_date,
a.tor_date,
a.tollgate_date,
a.draft_report_date,
a.final_report_date
FROM audit a 
LEFT JOIN team t ON a.team_id = t.team_id
LEFT JOIN sponsor s ON a.sponsor_id = s.sponsor_id
WHERE a.notification_date IS NOT NULL AND a.final_report_date IS NULL;

-- show resulting table

SELECT * FROM audits_in_flight;

-- use view to produce list of all in flight audits together with the audit team 

SELECT 
aif.audit_name,
CONCAT(m.manager_firstname, ' ', m.manager_lastname) AS audit_manager,
CONCAT (p.person_firstname,' ', p.person_lastname) AS auditor
FROM audits_in_flight aif
LEFT JOIN team t ON aif.team_name = t.team_name
LEFT JOIN manager m ON t.team_id = m.team_id
LEFT JOIN person p ON t.team_id= p.team_id;

