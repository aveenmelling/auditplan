USE audit;

/* create a stored function to check if a sponsor has any overdue audits (for weekly management meeting)
This means draft report has issued but sponsor has not yet approved it so final report has not issued
- draft report issued AND final report not issued = YES
- draft report not issued = NO
- final report issued = NO 
*/ 
-- creating the stored function
DELIMITER $$
CREATE FUNCTION outstanding_report (final_report_date DATE, draft_report_date DATE)
RETURNS varchar(10) DETERMINISTIC
BEGIN
	DECLARE outstanding VARCHAR(10);
    IF final_report_date IS NOT NULL THEN 
		SET outstanding = "No";
    ELSEIF draft_report_date IS NOT NULL AND final_report_date IS NULL THEN 
		SET outstanding = "Yes";
    ELSEIF draft_report_date IS NULL THEN
		SET outstanding = "No";
    ELSE 
		SET outstanding = "check input";
	END IF;

RETURN (outstanding);
END $$
DELIMITER ; 

-- calling the stored function 
SELECT 
a.audit_name,
CONCAT(s.sponsor_firstname, ' ', s.sponsor_lastname) as audit_sponsor,
outstanding_report (final_report_date, draft_report_date) AS outstanding -- call stored function
FROM audit a
LEFT JOIN sponsor s ON a.sponsor_id = s.sponsor_id
-- WHERE outstanding_report (final_report_date, draft_report_date) = "Yes"
-- run line above to return only outstanding audits
ORDER BY audit_sponsor;