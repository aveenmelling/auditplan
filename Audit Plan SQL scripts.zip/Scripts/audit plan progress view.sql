/* create view 'audit plan progress' pulling everything (except feedback) together into one table
this is effectively what we current have in a Sharepoint list except much tidier 
Provides an overarching view of the entire audit plan both current and historic 
and can be pulled into Power BI for reporting */ 

use audit;

CREATE VIEW audit_plan_progress AS
SELECT
a.audit_id,
a.audit_name,
t.team_name,
CONCAT(m.manager_firstname,' ', m.manager_lastname) AS manager,
CONCAT(s.sponsor_firstname, ' ', s.sponsor_lastname) AS sponsor,
CONCAT(sk.stakeholder_firstname,' ', sk.stakeholder_lastname) AS stakeholder,
a.notification_date,
a.tor_date,
a.tollgate_date,
a.draft_report_date,
a.final_report_date, 
st.current_status, 
g.grade,
p.audit_plan
FROM audit a 
LEFT JOIN team t ON a.team_id = t.team_id
LEFT JOIN manager m on m.team_id = t.team_id
LEFT JOIN sponsor s ON a.sponsor_id = s.sponsor_id
LEFT JOIN plan p ON a.plan_id = p.plan_id
LEFT JOIN grade g ON a.grade_id = g.grade_id
LEFT JOIN audit_status st ON a.status_id = st.status_id 
LEFT JOIN stakeholder sk ON a.stakeholder_id = sk.stakeholder_id;

select * from audit_plan_progress;
