CREATE DATABASE audit;
USE audit;

-- create PLAN TABLE - contains audit plan year

CREATE TABLE plan 
(
    plan_id	INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    audit_plan VARCHAR(4) NOT NULL
);

INSERT INTO plan (audit_plan) 
VALUES 
	(2020),
	(2021),
	(2022),
    (2023);
    
-- create STATUS TABLE - contains possible audit statuses

CREATE TABLE audit_status 
(
    status_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    current_status VARCHAR(30) NOT NULL
);

INSERT INTO audit_status (current_status)
VALUES
	('planning'),
	('fieldwork'),
    ('reporting'),
    ('housekeeping'),
    ('completed'),
    ('cancelled');


-- create SPONSOR TABLE - contains sponsor names 

CREATE TABLE sponsor 
(
    sponsor_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    sponsor_firstname VARCHAR(30) NOT NULL,
    sponsor_lastname VARCHAR(30) NOT NULL
);

INSERT INTO sponsor (sponsor_firstname, sponsor_lastname ) 
VALUES 
	('Christopher', 'Walken'),
	('Dennis', 'Hopper'),
	('Val', 'Kilmer'),
	('Elvis', 'Presley'),
	('Gary', 'Oldman'),
	('Drexl', 'Spivey');

-- create TEAM TABLE - contains agile team names

CREATE TABLE team 
(
    team_id	INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    team_name VARCHAR(10)
);

INSERT INTO team (team_name) 
VALUES 
	('1a'),
	('1b'),
	('2a'),
	('2b');

-- create MANAGERS TABLE - contains agile team manager names (not line managers)

CREATE TABLE manager 
(
    manager_id	INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    manager_firstname VARCHAR(30) NOT NULL,
    manager_lastname VARCHAR(30) NOT NULL,
    team_id INT NOT NULL, 
    FOREIGN KEY (team_id) REFERENCES team(team_id)
);

INSERT INTO manager (manager_firstname, manager_lastname, team_id ) 
VALUES 
	('Quentin', 'Tarantino', '1'),
	('Vincenzo', 'Coccotti', '2'),
	('Elliott', 'Blitzer', '3'),
	('Bronson', 'Pinchot', '4');

-- create PERSON TABLE - contains all audit team members & allocates to agile team

CREATE TABLE person 
(
    person_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    person_firstname VARCHAR(30) NOT NULL,
    person_lastname VARCHAR(30) NOT NULL,
    team_id  INT NOT NULL,
    FOREIGN KEY (team_id) references team(team_id)
);

INSERT INTO person (person_firstname, person_lastname, team_id ) 
VALUES 
	('Christian', 'Slater', '1'),
	('Clarence', 'Worley', '2'),
	('Alabama', 'Whitman', '3'),
	('Patricia', 'Arquette', '4'),
	('Brad', 'Pitt', '1'),
	('James', 'Gandolfini', '2'),
	('Clifford', 'Whitman', '3'),
	('Floyd', 'Pitt', '4'),
	('Samuel', 'Jackson', '1'),
	('Big', 'Don', '2'),
	('Michael', 'Rapaport', '3'),
	('Dick', 'Ritchie', '4');

-- create GRADE TABLE - contains all possible audit report grades

CREATE TABLE grade 
(
    grade_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    grade VARCHAR(30) NOT NULL
);

INSERT INTO grade (grade ) 
VALUES 
	('effective'),
	('needs improvement +'),
	('needs improvement'),
	('needs improvement -'),
	('ineffective');

-- create STAKEHOLDER TABLE - contains stakeholder names

CREATE TABLE stakeholder 
(
    stakeholder_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    stakeholder_firstname VARCHAR(30) NOT NULL,
    stakeholder_lastname VARCHAR(30) NOT NULL
);

INSERT INTO stakeholder (stakeholder_firstname, stakeholder_lastname ) 
VALUES 
	('Saul', 'Rubinek'),
	('Conchata', 'Ferrell'),
	('Mary-Louise', 'Ravencroft'),
	('Virgin', 'Gandolfini'),
	('Anna', 'Thomson'),
	('Victor', 'Argo'),
	('Chris', 'Penn'),
	('Nicky', 'Dimes'),
	('Tom', 'Sizemore'),
	('Cody', 'Nicholson'),
	('Gregory', 'Sporleder'),
	('Maria', 'Pitillo'),
	('Vincent', 'Vega'),
    ('John', 'Travolta'),
    ('Jules', 'Winnifield'),
    ('Uma', 'Thurman'),
    ('Mia', 'Wallace'),
    ('Harvey', 'Keitel'),
    ('Winston', 'Wolfe'),
    ('Ving', 'Rhames'),
    ('Marcellus', 'Wallace'),
    ('Bruce', 'Willis'), 
    ('Butch', 'Coolidge');
    

-- create AUDIT TABLE - contains all audit titles and details including milestone dates 

CREATE TABLE audit 
(
    audit_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    plan_id	INT NOT NULL,
    audit_name VARCHAR(150) NOT NULL,
    sponsor_id INT NOT NULL,
    stakeholder_id INT NOT NULL,
    team_id	INT NOT NULL,
    notification_date DATE,
    tor_date DATE,
    tollgate_date DATE,
    draft_report_date DATE,
    final_report_date DATE,
    grade_id INT,
	status_id INT,
    FOREIGN KEY (plan_id) REFERENCES plan(plan_id),
    FOREIGN KEY (sponsor_id) REFERENCES sponsor(sponsor_id),
    FOREIGN KEY (stakeholder_id) REFERENCES stakeholder(stakeholder_id),
    FOREIGN KEY (team_id) REFERENCES team(team_id),
    FOREIGN KEY (grade_id) REFERENCES grade(grade_id),
    FOREIGN KEY (status_id) REFERENCES audit_status(status_id)
);

INSERT INTO audit (plan_id, audit_name, sponsor_id, stakeholder_id, team_id, notification_date, tor_date, tollgate_date, draft_report_date, final_report_date, grade_id, status_id) 
VALUES 
	(1, 'Change Management', 1, 19, 1, '2020-10-31', '2020-11-12', '2020-12-30', '2021-01-09', '2021-01-31', 5, 5),
	(1, 'CASS Reporting', 2, 15, 2, '2020-07-11', '2020-07-21', '2020-09-16', '2020-09-19', '2020-10-06', 1, 5),
    (1, 'Risk Management Framework', 4, 17, 2, NULL, NULL, NULL, NULL, NULL, NULL, 6),
	(1, 'Project Jupiter', 3, 18, 3, '2020-08-04', '2020-08-14', '2020-10-05', '2020-10-10', '2020-10-26', 2, 5),
    (1,	'Payroll System Migration', 4, 18, 4, '2020-08-08',	'2020-08-14', '2020-09-30',	'2020-10-08', '2020-11-03', 2, 5),
	(1,	'Fund Manager Selection Process', 5, 13, 1, '2020-09-09', '2020-09-16', '2020-11-08', '2020-11-13', '2020-12-05', 5, 5),
	(1, 'Risk Framework', 6, 14, 2, '2020-02-08', '2020-02-22', '2020-04-07', '2020-04-12', '2020-05-03', 2, 5),
	(1, 'Compliance Assurance', 5, 7, 3, '2020-08-29', '2020-09-09', '2020-11-05', '2020-11-14', '2020-12-04', 2, 5),
	(1, 'Adviser Lending', 4, 7, 4, '2020-12-12', '2020-12-23', '2021-02-12', '2021-02-17', '2021-03-13', 4, 5),
    (1, 'Recruitment Process', 2, 11, 3, NULL, NULL, NULL, NULL, NULL, NULL, 6),
	(1, 'Business Sale & Purchase', 3, 19, 1, '2020-05-11', '2020-05-18', '2020-07-13', '2020-07-18', '2020-07-30', 5, 5),
	(1, 'Payroll', 2, 17, 2, '2020-01-23', '2020-02-07', '2020-03-31', '2020-04-06', '2020-04-23', 4, 5),
	(2, 'Value Assessments', 1, 3, 3, '2021-02-23', '2021-02-27', '2021-04-18', '2021-04-24', '2021-05-15', 4, 4),
	(2, 'Procurement', 2, 6, 4, '2021-10-18', '2021-10-24', '2021-12-13', '2021-12-15', '2021-12-19', 1, 4),
	(2, 'Data Architecture Team', 3, 9, 1, '2021-04-04', '2021-04-18', '2021-05-26', '2021-06-05', '2021-06-15', 2, 5),
	(2, 'New Bond Launch Operational Readiness', 4, 19, 2, '2021-10-17', '2021-10-29', '2021-12-24', '2022-01-03', '2022-01-17', 5, 5),
	(2, 'ISA/UT Servicing', 5, 10, 3, '2021-07-14', '2021-07-21', '2021-09-14', '2021-09-18', '2021-10-04', 3, 5),
	(2, 'Admin Centre Operations', 6, 17, 4, '2021-08-07', '2021-08-19', '2021-09-26', '2021-10-05', '2021-10-23', 2, 4),
    (2, 'Business Continuity', 5, 19, 1, '2021-07-28', '2021-08-11', '2021-09-27', '2021-10-02', '2021-10-15', 5, 4),
	(2, 'Disaster Recovery', 4, 2, 2, '2021-05-04', '2021-05-16', '2021-06-20', '2021-06-30', '2021-07-04', 3, 5),
	(2, 'COVID Response', 3, 12, 3, '2021-01-27', '2021-01-29', '2021-03-10', '2021-03-15', '2021-03-22', 1, 5),
	(2, 'Field Risk Oversight', 6, 8, 1, NULL, NULL, NULL, NULL, NULL, NULL, 6),
	(2, 'Liquidity Management', 2, 21, 4, '2021-01-11', '2021-01-19', '2021-02-26', '2021-03-03', '2021-03-06', 5, 5),
	(3, 'IT Project Governance', 1, 5, 1, '2022-12-04', '2022-12-15', '2023-02-03', '2023-02-11', '2023-03-03', 5, 5),
	(3, 'Learning & Development', 2, 20, 2, '2022-12-10', '2022-12-12', '2023-01-25', '2023-02-01', '2023-02-23', 5, 4),
	(3, 'CASS Reporting', 3, 16, 3, '2022-08-19', '2022-08-26', '2022-10-18', '2022-10-25', '2022-11-07', 4, 5),
	(3, 'FCA Consumer Duty', 4, 21, 4, '2022-08-28', '2022-09-03', '2022-11-02', '2022-11-12', '2022-12-01', 5, 5),
	(3, 'FCA Appointed Representative Regime', 5, 14, 1, '2022-06-25', '2022-06-30', '2022-08-25', '2022-08-27', '2022-09-19', 5, 4),
	(3, 'MiFID II', 6, 2, 2, '2022-02-23', '2022-03-05', '2022-04-29', '2022-05-04', '2022-05-17', 3, 5),
	(3, 'Environmental, Social & Governance (ESG)', 5, 19, 3, '2022-12-26', '2022-12-29', '2023-02-02', '2023-02-10', '2023-03-06', 2, 5),
	(3, 'Task Force on Climate-related Financial Disclosures (TCFD) Reporting', 4, 5, 4, '2022-04-15', '2022-04-26', '2022-06-06', '2022-06-08', '2022-06-28', 2, 5),
	(3, 'HR Processes', 3, 3, 1, '2022-10-01', '2022-10-04', '2022-11-18', '2022-11-26', '2022-12-03', 5, 5),
	(3, 'External Audit Controls Recommendations Follow Up', 2, 13, 2, '2022-07-25', '2022-08-06', '2022-09-26', '2022-10-05', '2022-10-14', 4, 5),
    (4, 'Cyber Security Controls', 5, 20, 1, '2023-01-12', '2023-01-15', '2023-01-20', '2023-02-28', NULL, NULL, 3),
    (4, 'Third Party Administrator Oversight', 4, 18, 2, '2023-01-10', '2023-01-13', NULL, NULL, NULL, NULL, 1),
    (4, 'Risk Management Framework', 4, 17, 3, '2023-01-04', '2023-01-09', NULL, NULL, NULL, NULL, 2);

-- create FEEDBACK TABLE (contains results of feedback survey sent to stakeholder following completion of audit)

CREATE TABLE feedback
(
	feedback_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    audit_id INT,
	stakeholder_id INT,
    q1_score	INT,
    q2_score	INT,
    q3_score	INT,
    q4_score	INT,
    q5_score	INT,
    comments	VARCHAR(512),
	FOREIGN KEY (audit_id) REFERENCES audit(audit_id),
    FOREIGN KEY (stakeholder_id) REFERENCES stakeholder(stakeholder_id)
);

INSERT INTO feedback (audit_id, stakeholder_id, q1_score, q2_score, q3_score, q4_score, q5_score, comments) 
VALUES
	(1, 19, 2, 4, 4, 1, 4,'the audit team was very polite'),
	(4, 18, 5, 4, 2, 3, 2, 'lots of useful recommendations'),
	(5, 13, 3, 4, 1, 5, 4, 'I found the audit very helpful'),
	(6, 14, 1, 3, 3, 5, 3, 'The audit took up a lot of my team’s time'),
	(7, 7, 5, 3, 4, 5, 4, 'The timing of the audit could have been better'),
	(8, 7, 1, 4, 2, 2, 2, NULL),
	(9, 19, 3, 2, 2, 1, 2, NULL),
	(10, 17, 3, 2, 1, 1, 4, 'thank you'),
	(11, 3, 1, 2, 4, 2, 1, NULL),
	(12, 6, 2, 2, 1, 2, 3, 'we will implement all of the recommendations'),
	(13, 9, 5, 5, 1, 2, 5, 'felt the grade was a bit harsh'),
    (14, 19, 1, 4, 4, 1, 3, NULL), 
	(15, 10, 3, 1, 1, 1, 4, 'I did not agree with some of the points raised'),
	(16, 17, 1, 3, 4, 3, 4, NULL),
	(17, 19, 4, 5, 4, 2, 4, 'thank you'),
	(18, 2, 2, 5, 2, 1, 3, 'the team was very professional'),
	(19, 12, 1, 2, 5, 3, 5, NULL),
	(20, 21, 2, 1, 5, 3, 4, 'did not feel we were listened to'),
	(21, 5, 1, 3, 5, 2, 2, 'the team was very helpful'),
	(22, 20, 4, 4, 5, 4, 3, NULL),
	(23, 16, 4, 2, 3, 1, 4, NULL);

select * from audit;


