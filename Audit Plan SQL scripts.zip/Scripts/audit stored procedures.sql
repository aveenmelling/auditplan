USE audit;

-- stored procedures 

/* create a STORED PROCEDURE to insert new feedback into the feedback table
to save having to type repetitive code */ 

DELIMITER $$

CREATE PROCEDURE insert_feedback (
		IN p_audit_id int, IN p_stakeholder_id int, IN p_q1_score int, IN p_q2_score int, IN p_q3_score int, IN p_q4_score int, IN p_q5_score int, IN p_comments varchar(512)
        )
					
BEGIN 
	INSERT INTO feedback (audit_id, stakeholder_id, q1_score, q2_score, q3_score, q4_score, q5_score, comments)
    VALUES (p_audit_id, p_stakeholder_id, p_q1_score, p_q2_score, p_q3_score, p_q4_score, p_q5_score, p_comments);
    
END $$

DELIMITER ;


-- call procedure to insert new feedback into the feedback table, amend as needed to insert new record
CALL insert_feedback (32, 3, 5, 4, 5, 5, 4, 'Thank you for all your help'); 
			
                
SELECT * FROM feedback; -- to see new record appended to end of table



/* create a stored procedure to produce a list of completed audits for which we have not received a completed questionnaire
for management to chase up */ 

-- create outstanding_feedback procedure
DELIMITER $$
CREATE PROCEDURE outstanding_feedback()
BEGIN
	SELECT 
	a.audit_name,
	ast.current_status,
	CONCAT(s.stakeholder_firstname, ' ', s.stakeholder_lastname) AS stakeholder,
	p.audit_plan
	FROM audit a
		LEFT JOIN stakeholder s ON a.stakeholder_id = s.stakeholder_id
		LEFT JOIN feedback f ON a.audit_id = f.audit_id
		LEFT JOIN plan p ON a.plan_id = p.plan_id
		LEFT JOIN audit_status ast ON a.status_id = ast.status_id
	WHERE current_status = 'completed' -- limit to records where the audit status is completed and we don't have a result for the feedback score
	AND q1_score IS NULL;

END$$
DELIMITER ; 

-- call outstanding feedback procedure 

CALL outstanding_feedback();

